package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class PedidosREST {
	
	@Autowired
	// Tenemos dos formas de solucionar cuando hay varios beans a inyectar:
	//      1ª utilizar @Primary
	//      2ª utilizar @Qualifier
	//@Qualifier("pedidosBSImplFeign")
	@Qualifier("feign")  // Hemos cambiado el nombre del bean
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	// Si tengo 50 metodos en esta clase, necesito 50 metodos alternativos
	// entonces, es mas viable utilizar un manejador de excepciones Globales
	//@HystrixCommand(fallbackMethod = "manejarError")
	@CircuitBreaker(fallbackMethod = "manejarError", name = "pedidos")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El metodo alternativo ha de tener los mismo argumentos + Throwable
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "************************");
		System.out.println(ex.getClass() + "************************");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	} 
	

}
