<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://www.springframework.org/tags" prefix="spring" %>
<!DOCTYPE html>
<html>
	<head>
	    <title>Pagina principal</title>
	</head>
	<body>
	    <h1>Bienvenidos a nuestra web</h1>
		
	  
		<a href="todos">Consultar todos los productos</a> <br/>
			
		<a href="buscar">Buscar un producto</a> <br/>
				
	</body>
</html>