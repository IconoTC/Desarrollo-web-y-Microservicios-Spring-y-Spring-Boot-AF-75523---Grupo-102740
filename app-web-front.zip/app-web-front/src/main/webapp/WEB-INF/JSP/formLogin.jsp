<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Formulario Login</title>
    </head>
    <body>
        <form action="login" method="POST" >
        
            <label>Usuario:</label>
            <input type="text" name="user"/> <br/>
			
			<label>Password:</label>
			<input type="password" name="pw"/> <br/>
            
            <input type="submit" value="Enviar" />
        </form>
    </body>
</html>
