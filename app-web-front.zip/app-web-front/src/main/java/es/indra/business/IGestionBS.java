package es.indra.business;

import java.util.List;

import es.indra.models.Carrito;
import es.indra.models.Producto;

public interface IGestionBS {
	
	List<Producto> obtenerTodos();
	
	Producto buscar(Long id);
	
	Carrito crear(String usuario);
	
	Carrito consultar(String usuario);
	
	void agregarPedido(Long id, int cantidad, String usuario);
	
	void eliminarPedido(Long id, String usuario);

}
