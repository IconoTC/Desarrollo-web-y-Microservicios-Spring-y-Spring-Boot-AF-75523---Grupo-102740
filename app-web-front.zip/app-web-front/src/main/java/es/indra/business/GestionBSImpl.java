package es.indra.business;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Carrito;
import es.indra.models.Producto;

@Service
public class GestionBSImpl implements IGestionBS {
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Producto> obtenerTodos() {
		String url = "http://localhost:8091/api/productos/listar";
		Producto[] productos = restTemplate.getForObject(url, Producto[].class);
		return Arrays.asList(productos);
	}

	@Override
	public Producto buscar(Long id) {
		String url = "http://localhost:8091/api/productos/buscar/{codigo}";
		return restTemplate.getForObject(url, Producto.class, id);
	}

	@Override
	public Carrito crear(String usuario) {
		String url = "http://localhost:8091/api/carrito/crear/{usuario}";
		return restTemplate.postForObject(url, null, Carrito.class, usuario);
	}

	@Override
	public Carrito consultar(String usuario) {
		String url = "http://localhost:8091/api/carrito/consultar/{usuario}";
		return restTemplate.getForObject(url, Carrito.class, usuario);
	}

	@Override
	public void agregarPedido(Long id, int cantidad, String usuario) {
		String url = "http://localhost:8091/api/carrito/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}";
		restTemplate.put(url, null, id, cantidad, usuario);
	}

	@Override
	public void eliminarPedido(Long id, String usuario) {
		String url = "http://localhost:8091/api/carrito/eliminar/id/{id}/usuario/{usuario}";
		restTemplate.delete(url, id, usuario);
	}

}
