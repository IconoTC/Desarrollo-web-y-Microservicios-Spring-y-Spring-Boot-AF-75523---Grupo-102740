package es.indra.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.business.IGestionBS;
import es.indra.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {
	
	@Autowired
	private IGestionBS bs;
	
	@GetMapping
	public String mostrarFormulario(Model model) {
		// Crear una instancia de Producto que enviamos al formulario
		// segun se rellenan los datos del formulario, crear las propiedades de la instancia
		model.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	
	@PostMapping
	public String procesarFormulario(@ModelAttribute("prod") Producto producto, Model model) {
		try {
			Producto encontrado = bs.buscar(producto.getID());
			model.addAttribute("encontrado", encontrado);
			return "mostrarProducto";
		} catch (Exception e) {
			// Si no encuentra el producto mostramos un mensaje
			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
			return "mostrarMensaje";
		}
		
	}

}
