package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = consultar(usuario);
		
		// Solo creo el carrito si no existe
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// Crear el pedido llamando al micro-servicio-pedidos
		Pedido pedido = clienteFeign.crear(id, cantidad);
		
		// Buscar el carrito de ese usuario
		Carrito carrito = consultar(usuario);
		
		// Agregar el pedido al contenido
		carrito.getContenido().add(pedido);
		
		// Actualizar el importe del carrito
		double importePedido = pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(importePedido + carrito.getImporte());
		
		// Guardar los cambios y retornar el carrito modificado
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		
		Pedido encontrado = carrito.getContenido()
								.stream()
								.filter(pedido -> pedido.getProducto().getID() == id)
								.findFirst()
								.get();
		
		// Si queremos borrar todos los pedidos con ese id
		//carrito.getContenido().removeAll(lista);
		
		// Nosotros solo borramos el primero que encontramos
		carrito.getContenido().remove(encontrado);
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		return dao.save(carrito);
	}

}













