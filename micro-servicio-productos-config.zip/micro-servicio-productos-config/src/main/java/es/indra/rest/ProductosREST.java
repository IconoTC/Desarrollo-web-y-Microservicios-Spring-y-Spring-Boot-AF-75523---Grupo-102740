package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.business.ProductosBSImpl;
import es.indra.entities.Producto;

@RestController
//@RefreshScope
public class ProductosREST {

    private final ProductosBSImpl productosBSImpl;
	
	@Autowired   // para inyectar beans
	private IProductosBS bs;
	
	@Value("${server.port}")     // para inyectar valores (primitivos y String)
	private Integer port;
	
	// Inyectamos el valor de la propiedad recibida del servidor de configuracion
	@Value("${perfil.configuracion}")
	private String texto;

    ProductosREST(ProductosBSImpl productosBSImpl) {
        this.productosBSImpl = productosBSImpl;
    }
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		// Mostrar el perfil
		System.out.println("******************** Estamos en el perfil: " + texto);
		
		return bs.consultarTodos().stream()
					.map(prod -> {
						prod.setPort(port);
						return prod;
					})
					.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) throws InterruptedException {
		// Mostrar el perfil
		System.out.println("******************** Estamos en el perfil: " + texto);
		
		Producto producto = bs.buscarProducto(id);
		
		// Si no encontramos el producto, lanzamos una excepcion
		if (producto.getDescripcion() == null)
			throw new RuntimeException("Error al buscar el producto");
		
		// Probar las peticiones lentas
		if (id == 5L) {
			Thread.sleep(5000);
		}
		
		producto.setPort(port);
		return producto;
	}

}
