package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring (crear el contenedor y detectar todos los beans)
		// Empieza a buscar por los paquetes es.indra
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
